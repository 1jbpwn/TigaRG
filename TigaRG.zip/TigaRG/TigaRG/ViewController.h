//
//  ViewController.h
//  TigaRG
//
//  Created by Deegan  Young on 2017-11-26.
//  Copyright © 2017 tigris. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


- (IBAction)mach:(id)sender;

@end

