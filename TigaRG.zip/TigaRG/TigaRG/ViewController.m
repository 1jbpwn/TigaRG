//
//  ViewController.m
//  TigaRG
//
//  Created by Deegan  Young on 2017-11-26.
//  Copyright © 2017 tigris. All rights reserved.
//

#import "ViewController.h"
#include <spawn.h>
extern char **environ;


@interface ViewController ()

@end

@implementation ViewController

- (IBAction)runep:(id)sender{
// Run Code For Jailbreak Button Make sure to include or import then add files first
    
    
    system("killall -9 springboard");
    system("killall backboardd");
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
