//
//  ViewController.m
//  Dawn090
//
//  Created by Deegan  Young on 2017-11-27.
//  Copyright © 2017 frim. All rights reserved.
//


#import "ViewController.h"
#include <spawn.h>
#include <offsets.h>
#include <offsets.m>
#include <post_exploit.h>
#include <post_exploit.m>
#include <patchfinder64.o>





/*
 
 TigaRG By ZiVa (kernal) Fcukboi (kpp) mharris (sideloading ui remake .tar file)

 
 Purple Lambrogini
 -----------------
 Biggest boss and I been the trillest
 I'm a bigger problem when I click with Skrillex
 Murder on my mind, it's time to pray to God
 My revolver is not religious, the revolution’s born
 You wanna know my name then go and tell the Sarg
 You wanna know my gang: Suicide Squad
 Pistol on my waist, I might make a mistake
 Dead shot, head shot, oh my god, am I crazy?
 Drugs every corner, this is Gotham City
 Killer Croc came to kidnap you, to cut out your kidney
 Ain't no mercy, got that purple Lamborghini lurkin'
 Rozay, don't you know that pussy worth it
 Flooded Rolex at the Grammy awards
 They still sellin' dope, that's those Miami boys
 Killers everywhere, it ain't no place to run
 Forgive me for my wrongs, I have just begun
 Ain't no mercy, a-ain't no mercy
 Got that purple Lamborghini lurkin'
 Ain't no mercy, a-ain't no mercy
 Got that purple Lamborghini lurkin (Rozay!)
 Don't be beggin' for your life cause that's a lost cause
 High stakes, body armor, suicide boy
 There's a time for games and there's a time to kill
 Make up your mind baby cause the time is here
 Capital murder, capital lettuce
 Yeah she catchin' my vibe but can't fathom my cheddar
 Need a couple gang members for these new endeavors
 From this point on anything we do, we do together
 Body on the corner, million in the trunk
 Seven figures, I will spend that every other month
 Killers on the corner, talons in the clip
 Build a palace out in Paris just to fill with bitches
 Say my name and I’m coming with the gun squad
 Everybody runnin', homie, there’s only one God
 Cocaine, white Ferrari, I'm in the fast lane
 Every day was life and death, that's when the cash came
 Count money, drug residue even blood on it
 He had a trap 'til I put my cuz on it
 Kickin’ in the dope boy, Suicide Squad
 Needle in my arm so I’m do or die for it
 Ain't no mercy, a-ain't no mercy
 Got that purple Lamborghini lurkin'
 Ain't no mercy, a-ain't no mercy
 Got that purple Lamborghini lurkin', Rozay
 
 
 D I S T R A C T I O N
*/





@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)mach:(id)sender{
    
    char *command[] = {
        "killall",
        "SpringBoard",
        NULL
    };
    posix_spawn(NULL, command[0], NULL, NULL, command, NULL);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
