#include <stdint.h>
#include <stdlib.h>


#ifndef __UTILS_H_
#define __UTILS_H_




char * utils_get_base64_payload(void * buffer, size_t length);



#endif /* __UTILS_H_ */