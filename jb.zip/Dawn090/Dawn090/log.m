/* This is a placeholder for the log.h file, so the compiler won't cry.

                                                                                                    
                                                                                                    
                                           `.-..:+sss+:.                                            
                                        `+yhddddddmmmmmds:`                                         
                                     `-/hmdddmdmdddmmdmmmddho/-`                                    
                                   -hddmmmdddddddddmmdddddmdmmdo`                                   
                                  `dddddmmmdddmdddddmdddddmdddmd+                                   
                                  omddddmNmdddmddddmmddmdmmdddmmd.                                  
                               -/ydmmmdmmmNNmddNmddmmddmmmmmmmmmmo                                  
                              /hdddddmmmmmNNNmmmNmmmNmmNmNmmmmmmmm/                                 
                             .dddddddmmmmmmddddddhhhhhhhhhhhmmNNNmd`                                
                             -mmmmmNmho/:::::::-------------/hNNmmm+                                
                             -dmmmmy/------------------------:hmmddh.                               
                             `smmms---------------------------/dddddo                               
                              .mmm:---------------------------:smdddy                               
                              `dmd-----------------------------/ddddh`                              
                               dmd-----------------------------:ddddd.                              
                               ymh-----------------------------/mdddd.                              
                               +ms-----------------------------:ydddy                               
                               .ds--+syyysso/-----/oyyhhhhhs+::/+mmm+.                              
                              `dmdsososssssyhy+/+odhysooo+//+odmmmNs-::                             
                              -yNm:--:+oyyo+:sMNNNo::o+yyso/--/N++m:-:+                             
                              ::om---::-:::/:sm/-oh-::--------:d::d:--+                             
                              `/+m:---------:do---+s----------o/::d::-/                             
                               -/ss+/::::/+os:-----:o+o+++++++/--:s--/.                             
                                /+--::///::/--------::-----------+/-:-                              
                                 /---------:::----::/:--:-------+h::.                               
                                 .o---:ssyyyyyo+/oyyhhhhyss:--:syy`                                 
                                  so:-+hhys+++oooo+////+yhh+--syho                                  
                                  :hs/-ys+yo```.......-s+oy+:oyyh-                                  
                                   oyy/oy--::-......--::-syssyyhs                                   
                                   `oyysy/--://::///+:--+yyyyyhy.                                   
                                    `/yyyy+::ossssss+::+yyyyyhy-                                    
                                      -shhysssyyyyyysssyhhyyhs.                                     
                                       `+hhyyyyyyyyyyyyyhhhs/:                                      
                                        .syhhyhhhhhyyyhdhs/--s:`                                    
                                      `:ss-/shddmdddhhy+/----dds:`                                  
                                     -osss---:/+++++//::-----+dsso-                                 
                                  `.+sssss-----::::::::-------hssss/`                               
                            `.-:/+syyyysss------:::::--------:hssosy+.``                            
                      `..:/+oossoyyyyyhyss:------------------+yssssssyoo+/-.``                      
                 `.:/+ossssssssyssyssshhys/:-----------------hsyhhhhhyyysssyso+/-.`                 
                -osssosssosssossooysosyhhss+:---------------/yshyyssyssssoossssssso+:`              
               -sssysssssssssssssoyssssyhhyso:-------------/ssysssssssssyssyssssssssso/`            
              .sssoysssssssssosssoysssssssyhhy:----------/ossysossosssssssossossssssssss.           
              ossssysosssssssossoossosssssssshh/-------:osossyssyssssssssssssoossosssssss.          
             :ssysyysssysssssssyssysssssssssssyh+-----/ssyyhyssossosyssssssssssyyssysyssss`         
            `sssyshysssssssssssssoysosssssssosssy+---ossyhysssssssoossosssssssossoosyyssss+         
            /soshshysosssosssossoossosssosssossosy:-syyssysssssssssssyssysssssssssoshssssos-        
           `yssshyhysssysssssssyssysssssssssssyssyyyysssossoossssssossoossossssssssydysyssss        
           /ssssyyyhsssssssssossoossosssssssossossysssssssyssysssssssssossoossosssshhhossooy:       


*/